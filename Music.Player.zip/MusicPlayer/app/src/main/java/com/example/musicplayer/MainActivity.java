package com.example.musicplayer;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.example.musicplayer.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {
    private Button playBtn;
    ActivityMainBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();
        setContentView(view);

        //Criado Media player object
        //
        MediaPlayer mediaPlayer= MediaPlayer.create(this,R.raw.song01);

        // add funcionalidades ao seekbar

        //add maximo valor  ao seebar na duracao da musica em tempo de execucao

        //envento do button play
        binding.playBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //ter a certeza se o player esta funcionado
                if (!mediaPlayer.isPlaying()) {
                    mediaPlayer.start();
                    //caso sim, trocamos a imagem
                    binding.playBtn.setImageResource(R.drawable.baseline_pause_24);

                }else {//esta funcionado , agora podemos pausar;
                    mediaPlayer.pause();
                    binding.playBtn.setImageResource(R.drawable.baseline_play_arrow_black);


                }
            }
        });



    }
}