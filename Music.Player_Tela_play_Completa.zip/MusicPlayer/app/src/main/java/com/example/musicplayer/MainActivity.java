package com.example.musicplayer;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;

import androidx.appcompat.app.AppCompatActivity;

import com.example.musicplayer.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {
    private Button playBtn;
    //private SeekBar seekBar;
    ActivityMainBinding binding;

    //torca de posicao de seekbar enuqanto a musica esta no play
    //Criamo os metodos abaixo runnable e handler para tal

    private Runnable runnable;
    Handler handler = new Handler();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();
        setContentView(view);

        //Criado Media player object

        MediaPlayer mediaPlayer= MediaPlayer.create(this,R.raw.song01);

        // add funcionalidades ao seekbar
        binding.seekbar.setProgress(0);
        //add maximo valor  ao seekbar na duracao da musica em tempo de execucao
        binding.seekbar.setMax(mediaPlayer.getDuration());


        //envento do button play
        binding.playBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //ter a certeza se o player esta funcionado
                if (!mediaPlayer.isPlaying()) {
                    mediaPlayer.start();
                    //caso sim, trocamos a imagem
                    binding.playBtn.setImageResource(R.drawable.baseline_pause_24);

                }else {//esta funcionado , agora podemos pausar;
                    mediaPlayer.pause();
                    binding.playBtn.setImageResource(R.drawable.baseline_play_arrow_black);


                }
            }
        });

        //Agora iremos adicionar um enveto ao seek bar
        binding.seekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

            //progess =changed; pos=positio
            @Override
            public void onProgressChanged(SeekBar seekBar, int pos, boolean changed) {
                // trocar a posicao dp seekbar na musica ate estar na ppsicao x desejada
                mediaPlayer.seekTo(pos);



            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                // código a ser executado
                binding.seekbar.setProgress(mediaPlayer.getCurrentPosition());
                handler.postDelayed(this, 100);



            }
            
        };
        handler.postDelayed(runnable, 100);
        mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mediaPlayer) {
                binding.playBtn.setImageResource(R.drawable.baseline_play_arrow_black);
                binding.seekbar.setProgress(0);
            }
        });



    }
}